def check_balance(balance):
    print(f"Your Balance is {balance} rupee")


def deposit():
    amount = int(input("Enter Amount to deposit: "))
    if amount <= 0 :
        print("Not a Valid Amount")
        return 0
    else:
        return amount



def withdraw(balance):
    amount = int(input("Enter amount to withdraw: "))
    if amount > balance:
        print("Insufficient Balance")
        return 0
    elif amount<0:
        print("Amount must be greater than zero")
        return 0
    else:
        return amount


def main():
    balance = 0
    is_running = True

    while is_running:
        print("****************")
        print("   Banking  ")
        print("*****************")
        print(" 1.Show Balance ")
        print(" 2.Make Deposit")
        print(" 3.Withdraw Money")
        print(" 4.Exit")
        choice = int(input("Enter your choice (1 to 4) :"))

        if choice == 1:
            check_balance(balance)
        elif choice == 2:
            balance += deposit()
        elif choice == 3:
            balance -= withdraw(balance)
        elif choice == 4:
            is_running = False
        else:
            print("Not a Valid Choice")
    print(" Thankyou! Have a nice day")

if __name__=='__main__':
    main()
